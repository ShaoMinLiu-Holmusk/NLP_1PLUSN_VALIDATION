# Instructions

## Preparation  

To use this package, you need to obtain the relevant pre-trained BERT and classifier (IE) models.   
You can download all the trained models from S3 bucket by 
`./download.sh`

The model will require a pretrained BERT model (Bio-DischargeSummaryBERT), of which, the following files are required:  
* bert_config.json  
* pytorch_mode.bin  
* tokenizer_config.json  

Each IE model is assumed to have the following relevant files:  

* modelConfig.json
* pytorch_model.bin  
* data_labelKeys_*.json  
* data_thresholds_*.json  
* data_filters_*.json (optional)  

Place the required models in your local directories, create a config file.  
You may follow the template:  
`holbert/config/package_config_main.json`  

## Configurations  

Config Name | Description  
-- | :---    
SupportedModel | The list of submodels with the corresponding on/off flag. If False, submodel is not being used.
BertPath | Directory to the pretrained Bio-DischargeSummaryBERT model
Device | Set it to "gpu" to always run on gpu, analogously for "cpu"; "auto" will use gpu whenever available  
KeepTokens | Whether or not to keep a copy of the input string and tokens in the output; set to False will save on some processing time and ram resources  
topicLabMaptoClassifer | Key mapping to the output of topicLab to the relevant Classifier, advisable not to edit this unless there is naming convention changes made to classifiers  
filterSubLevel | whether to allow a classifier to remove prediction result of another classifer; for example, if sentenceClassifier predict that a MSE is not present in a sentence, a filter could veto the result and turn the prediction of MseClassifier to false, regardless of MseClassifier's result  

## Example  

### Loading model

```{python}
sampleText = 'This is a testing sentence.'
sampleTextList = ['This is a testing sentence.',
                  'another sentence is here',
                  'what do you say about this sentence?']
```

```{python}
from holbert import BertForPackage
model = BertForPackage("./holbert/config/package_config_main.json")
```  

### Analyzing Text  

```{python}
# accepts a string
result = model.processDocument(sampleText)  


# accepts a list of strings
result = model.processDocument(sampleTextList)



# specify only to predict using SentenceClassifier
# classifier argument is limited to the `SupportedModel`
# in the config json

result = model.classify(classifier = 'SentenceClassifier',
                        text = sampleText)

# also accepts a List of string
result = model.classify(classifier = 'SentenceClassifier',
                        text = sampleTextList)

# other classifiers
result = model.classify(classifier = 'MseClassifier',
                        text = sampleTextList)
```

### Manipulating Result  

#### Readable
All results generated from holbert is a `ClinicianNote` object, some with nested structure.

```{python}
result = model.processDocument(sampleText)  

# np.ndarray of probability (raw)
result.prob


# sparse probability processed 
# by threshold and filter
result.sparseProb

# readable text version of sparseProb
result.readable
```

#### Thresholds  
You can adjust the threshold of the classifiers 

```{python}
result = model.processDocument(sampleText)  

new_thresholds = {
    'MseClassifier': {
        'mseLab': [0.1, 0.3, 0.4, ...],
        'mseC_neg': [ ... ]
    }
}

result.thresholds = new_thresholds

# readable text will be produced 
# according to the thresholds
result.readable
```

A second way to change threholds
```{python}
result = model.processDocument(sampleText)  

new_thresholds = [0.1, 0.3, 0.4, ...]
result.SentenceClassifier.topicLab.thresholds = new_thresholds
```




