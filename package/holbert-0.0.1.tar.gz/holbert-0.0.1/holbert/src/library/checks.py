import os

def exists(path):
    if not os.path.exists(path):
        print(f'You have specified path {path} in the config, but it is not present')
        return False

    return True

modelFiles = {
    "BertPath": [
        'pytorch_model.bin',
        'vocab.txt',
        'bert_config.json',
        'tokenizer_config.json'
    ],
    "SupportedModel": [
        'pytorch_model.bin',
        'modelConfig.json'
    ]
}

def modelFileCheck(path):
    pass



exclusionList = ['Device', 'tempCache']

def check(config):
    '''This function checks that all paths specified in config exist'''

    for i,j in config.items():
        if isinstance(j, str):
            if i not in exclusionList:
                if not exists(j):
                    return False
        elif isinstance(j, dict):
            check(j)

