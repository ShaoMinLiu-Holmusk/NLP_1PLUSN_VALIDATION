import os

rootDir = (os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'config', 'preprocessing'))

preprocessing = {
    "tempCache": "./results/temp",
    "abbreviations": f"{rootDir}/abbreviations.csv",
    "medical_terms_text": f"{rootDir}/add_to_dict.txt"
}
